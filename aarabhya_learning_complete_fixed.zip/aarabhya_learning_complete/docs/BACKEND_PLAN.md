# Backend integration starter (design notes)

Recommended production stack:
- Frontend: existing HTML/CSS/JS prototype; migrate to React/Next.js when ready.
- Backend: Node.js + Express or Next.js server routes.
- Database: PostgreSQL (e.g. Supabase).
- Authentication: managed auth provider with server-verified sessions.
- AI: call the provider from a server route; never expose API keys in browser code.
- Hosting: HTTPS-enabled host with environment variables and backups.

Suggested API routes:
POST /api/auth/session
GET /api/courses
POST /api/courses                 (teacher/admin)
GET /api/assignments
POST /api/assignments             (teacher/admin)
POST /api/submissions
GET /api/student/progress
POST /api/ai/tutor                (server-side AI call)

Before production:
1. Implement authentication and server-side role checks.
2. Enable PostgreSQL row-level security.
3. Validate and rate-limit every API request.
4. Keep secrets in server environment variables.
5. Add audit logs, backups, monitoring and HTTPS.
6. Perform security and accessibility testing.
7. Establish adult/institutional oversight and privacy practices for minor students.

The included browser demo is not a production backend and must not be used for real student records.
