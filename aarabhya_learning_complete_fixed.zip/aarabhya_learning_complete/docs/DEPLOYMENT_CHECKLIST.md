# Deployment checklist

- [ ] Move frontend into a production framework/build pipeline.
- [ ] Provision managed PostgreSQL and apply schema.sql.
- [ ] Configure managed authentication and role-based authorization.
- [ ] Enable row-level security and test student/teacher/admin boundaries.
- [ ] Implement backend API routes and validation.
- [ ] Configure AI provider on server only; add usage limits.
- [ ] Add privacy notice, age-appropriate consent and guardian/institution review.
- [ ] Configure HTTPS, domain, backups, monitoring and error reporting.
- [ ] Test keyboard access, mobile layouts, accessibility and security.
- [ ] Deploy staging first, then production.
