-- PostgreSQL starter schema (review and adapt before production)
create table profiles (
  id uuid primary key,
  display_name text not null,
  role text not null check (role in ('student','teacher','admin')),
  created_at timestamptz default now()
);
create table courses (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  teacher_id uuid references profiles(id),
  created_at timestamptz default now()
);
create table enrollments (
  student_id uuid references profiles(id),
  course_id uuid references courses(id),
  created_at timestamptz default now(),
  primary key(student_id, course_id)
);
create table assignments (
  id uuid primary key default gen_random_uuid(),
  course_id uuid references courses(id),
  title text not null,
  due_at timestamptz,
  created_by uuid references profiles(id)
);
create table submissions (
  id uuid primary key default gen_random_uuid(),
  assignment_id uuid references assignments(id),
  student_id uuid references profiles(id),
  status text default 'pending',
  submitted_at timestamptz
);
create table notes (
  id uuid primary key default gen_random_uuid(),
  student_id uuid references profiles(id),
  title text,
  body text,
  created_at timestamptz default now()
);
-- Production: enforce row-level security for every table.
-- Students may read/update only their own profile, notes and submissions.
-- Teachers may manage only courses/assignments they own.
-- Admin actions must be audited and restricted.
